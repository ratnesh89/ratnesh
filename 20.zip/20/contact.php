<?php
// contact.php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    if (!empty($name) && !empty($email)) {
        echo "Thank you, " . htmlspecialchars($name) . "! We will get back to you at " . htmlspecialchars($email) . ".";
    } else {
        echo "Please fill out both fields.";
    }
}
?>
